<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_usermessage`;");
E_C("CREATE TABLE `zzcms_usermessage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `looked` tinyint(4) NOT NULL DEFAULT '0',
  `reply` varchar(1000) DEFAULT NULL,
  `replytime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_usermessage` values('2',NULL,'test','2013-11-27 11:29:34','test','1','ooooooooooooo','2014-07-14 18:16:23');");

require("../../inc/footer.php");
?>