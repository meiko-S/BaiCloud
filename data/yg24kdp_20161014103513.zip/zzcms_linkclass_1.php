<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_linkclass`;");
E_C("CREATE TABLE `zzcms_linkclass` (
  `bigclassid` int(11) NOT NULL AUTO_INCREMENT,
  `bigclassname` varchar(255) DEFAULT NULL,
  `xuhao` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bigclassid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_linkclass` values('1','合作网站','1');");
E_D("replace into `zzcms_linkclass` values('2','友情链接','2');");
E_D("replace into `zzcms_linkclass` values('3','媒体支持','0');");

require("../../inc/footer.php");
?>