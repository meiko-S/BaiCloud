<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_guestbook`;");
E_C("CREATE TABLE `zzcms_guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` longtext,
  `sendtime` datetime DEFAULT NULL,
  `linkmen` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `saver` varchar(50) DEFAULT NULL,
  `looked` tinyint(4) DEFAULT '0',
  `passed` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=364 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_guestbook` values('1','segsgbs','dgbrdsgbedbr','2013-04-11 17:41:30','fdgbdfgbdfgbdf','gbdfgbdfgb','dfgbdfgbd','sxdayehaiyy','0','1');");
E_D("replace into `zzcms_guestbook` values('2','segsgbs','dgbrdsgbedbr','2013-04-11 17:41:49','fdgbdfgbdfgbdf','gbdfgbdfgb','dfgbdfgbd','sxdayehaiyy','0','1');");
E_D("replace into `zzcms_guestbook` values('4','是大人气味儿','烧饭的撒个','2013-07-04 15:54:44','广东省公司','12345678910','11@163.com','123456','1','1');");
E_D("replace into `zzcms_guestbook` values('87','','测试一下留言效果，有什么支持？','2013-10-16 23:34:39','郑州的','13612361258','','sdhksw','0','1');");
E_D("replace into `zzcms_guestbook` values('88','','我对你们的产品感兴趣，请与我联系。有什么支持？请寄给我样品。请寄给我详细资料。','2013-11-18 13:39:00','老李','11222333445','asdf@qq.com','ttt111','0','1');");
E_D("replace into `zzcms_guestbook` values('275','','我对你们的产品感兴趣，请与我联系。有什么支持？请寄给我详细资料。请寄给我样品。','2014-03-12 16:21:08','89943198','11222333445','','sdhksw','0','1');");
E_D("replace into `zzcms_guestbook` values('282','','我对你们的产品感兴趣，请与我联系。有什么支持？','2014-04-20 20:57:31','张经理','15599665555','','xmmhyy','0','1');");
E_D("replace into `zzcms_guestbook` values('283','','真实名','2014-05-09 19:17:31','真实名','12512361247','','zjmyy','0','1');");
E_D("replace into `zzcms_guestbook` values('285','','jiu jiu我对你们产品感兴趣，请与我联系。代理价零售价是123？','2014-06-05 12:10:40','liuxiansheng','13686464449','14462493@qq.com','{#saver}','0','1');");
E_D("replace into `zzcms_guestbook` values('294',NULL,'我对你们的产品感兴趣，请与我联系。有什么支持？请寄给我详细资料。请寄给我样品。','2014-11-13 16:25:27','','','394308167@qq.com','test56','1','1');");
E_D("replace into `zzcms_guestbook` values('351',NULL,'cesihhhh有什么支持？','2016-03-08 14:23:07','扎西德说的','15534526765','','cn35553cn','0','1');");
E_D("replace into `zzcms_guestbook` values('357',NULL,'我对这个产品感兴趣，请与我联系。','2016-03-15 23:08:19','李志阳','138380641122','','qlmdb2015','0','1');");
E_D("replace into `zzcms_guestbook` values('358',NULL,'我对你们产品感兴趣，请与我联系。','2016-03-16 14:31:44','李志阳','13838064118','','test','1','1');");
E_D("replace into `zzcms_guestbook` values('359',NULL,'愿加盟“纽崔莱”这个品牌，请与我联系。','2016-03-17 19:58:54','李志阳','13838064113','','test','1','1');");
E_D("replace into `zzcms_guestbook` values('360',NULL,'我对你们的产品感兴趣，请与我联系。','2016-03-18 09:06:12','李志阳','13838064114','','test','1','1');");
E_D("replace into `zzcms_guestbook` values('362',NULL,'我对你们产品感兴趣，请与我联系。代理价零售价是多少？','2016-04-24 18:18:50','陶先生','18522601991','','ghswyy','1','1');");
E_D("replace into `zzcms_guestbook` values('363',NULL,'hgjgjfgj','2016-06-09 21:49:12','个和','13666666666','dfe@sdhfg.com','mz3294003185','0','0');");

require("../../inc/footer.php");
?>