<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_zsclass_shuxing`;");
E_C("CREATE TABLE `zzcms_zsclass_shuxing` (
  `bigclassid` int(11) NOT NULL AUTO_INCREMENT,
  `bigclassname` varchar(255) DEFAULT NULL,
  `xuhao` int(11) DEFAULT '0',
  PRIMARY KEY (`bigclassid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_zsclass_shuxing` values('5','OTC','1');");
E_D("replace into `zzcms_zsclass_shuxing` values('6','RX','2');");

require("../../inc/footer.php");
?>