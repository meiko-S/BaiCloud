<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_dl_yaozhuang`;");
E_C("CREATE TABLE `zzcms_dl_yaozhuang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dlid` int(11) DEFAULT '0',
  `cpid` int(11) DEFAULT '0',
  `cp` varchar(255) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `xiancheng` varchar(50) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `dlsname` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `editor` varchar(255) DEFAULT NULL,
  `saver` varchar(255) DEFAULT NULL,
  `savergroupid` int(11) DEFAULT '0',
  `ip` varchar(255) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `hit` int(11) DEFAULT '0',
  `looked` tinyint(4) DEFAULT '0',
  `passed` tinyint(4) DEFAULT '0',
  `del` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `province` (`province`,`city`,`xiancheng`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");

require("../../inc/footer.php");
?>