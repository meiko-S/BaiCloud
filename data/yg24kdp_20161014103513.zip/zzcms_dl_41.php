<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("replace into `zzcms_dl` values('20033','0','0','脑蛋白水解物注射液',NULL,'全国吉林延边',NULL,'韩忠权',NULL,NULL,'韩忠权',NULL,'13043365777','',NULL,NULL,'0',NULL,'2014-11-29 10:34:00','30','0','1','0');");
E_D("replace into `zzcms_dl` values('20034','0','0','萘丁美酮分散片',NULL,'全国吉林四平',NULL,'萘丁美酮分散片',NULL,NULL,'李岩',NULL,'13844401567','',NULL,NULL,'0',NULL,'2014-11-29 10:34:00','30','0','1','0');");
E_D("replace into `zzcms_dl` values('20035','0','0','风湿，肠胃，妇科，儿科，心脑，肝胆，皮肤，鼻咽炎，支气管炎，结石，痔疮类等',NULL,'全国安徽',NULL,'王传辉',NULL,NULL,'王传辉',NULL,'6711885/3194696','',NULL,NULL,'0',NULL,'2014-11-29 10:34:00','31','0','1','0');");
E_D("replace into `zzcms_dl` values('20036','0','0','皮癣灵，痘必治',NULL,'全国广东江门',NULL,'王耀彬',NULL,NULL,'王耀彬',NULL,'0750―8371348','',NULL,NULL,'0',NULL,'2014-11-29 10:34:00','31','0','1','0');");
E_D("replace into `zzcms_dl` values('20037','0','0','心脑血栓类肿瘤类抗生素类',NULL,'全国广东',NULL,'曾东华',NULL,NULL,'曾东华',NULL,'020―33606128','',NULL,NULL,'0',NULL,'2014-11-29 10:35:00','37','0','1','0');");
E_D("replace into `zzcms_dl` values('20038','0','0','羊妈咪羔羊胃提取物维B12颗粒',NULL,'全国',NULL,'我对这个产品感兴趣，请与我联系。',NULL,NULL,'李志阳',NULL,'13007531076','',NULL,NULL,'0',NULL,'2014-11-29 10:36:00','36','0','1','0');");
E_D("replace into `zzcms_dl` values('20039','0','0','心脑血栓类肿瘤类抗生素类',NULL,'广东',NULL,'曾东华',NULL,NULL,'曾东华',NULL,'020―33606128','',NULL,NULL,'0',NULL,'2014-11-29 10:36:00','40','0','1','0');");
E_D("replace into `zzcms_dl` values('20040','0','0','皮癣灵，痘必治',NULL,'广东江门',NULL,'王耀彬',NULL,NULL,'王耀彬',NULL,'0750―8371348','',NULL,NULL,'0',NULL,'2014-11-29 10:36:00','43','0','1','0');");
E_D("replace into `zzcms_dl` values('20041','0','0','国药准字号药品',NULL,'山西大同',NULL,'侯旭峰',NULL,NULL,'侯旭峰',NULL,'0349―8831447','',NULL,NULL,'0',NULL,'2013-04-17 11:42:00','39','0','1','0');");
E_D("replace into `zzcms_dl` values('20042','0','0','风湿，肠胃，妇科，儿科，心脑，肝胆，皮肤，鼻咽炎，支气管炎，结石，痔疮类等',NULL,'安徽',NULL,'王传辉',NULL,NULL,'王传辉',NULL,'6711885/3194696','',NULL,NULL,'0',NULL,'2014-11-29 10:36:00','43','0','1','0');");
E_D("replace into `zzcms_dl` values('20043','0','0','999曲景减肥胶囊',NULL,'河北',NULL,'欧彦攀',NULL,NULL,'欧彦攀',NULL,'13131899810','',NULL,NULL,'0',NULL,'2013-04-17 11:29:00','43','0','1','0');");
E_D("replace into `zzcms_dl` values('20044','0','0','蒲参胶囊',NULL,'河南',NULL,'刘经理',NULL,NULL,'刘经理',NULL,'3705135277','',NULL,NULL,'0',NULL,'2013-04-17 11:28:00','38','0','1','0');");
E_D("replace into `zzcms_dl` values('20045','0','0','妇科等',NULL,'江西',NULL,'孙总',NULL,NULL,'孙总',NULL,'13197855332','',NULL,NULL,'0',NULL,'2014-11-29 10:34:00','38','0','1','0');");
E_D("replace into `zzcms_dl` values('20046','0','0','胆龙止喘片',NULL,'河南平顶山',NULL,'胆龙止喘片',NULL,NULL,'温春雷',NULL,'13781855721','',NULL,NULL,'0',NULL,'2014-11-29 10:34:00','65','0','1','0');");
E_D("replace into `zzcms_dl` values('20047','0','0','萘丁美酮分散片',NULL,'吉林四平',NULL,'萘丁美酮分散片',NULL,NULL,'李岩',NULL,'13844401567','',NULL,NULL,'0',NULL,'2014-11-29 10:34:00','60','0','1','0');");
E_D("replace into `zzcms_dl` values('20048','0','0','脑蛋白水解物注射液',NULL,'吉林延边',NULL,'韩忠权',NULL,NULL,'韩忠权',NULL,'13043365777','',NULL,NULL,'0',NULL,'2014-11-29 10:36:00','65','0','1','0');");
E_D("replace into `zzcms_dl` values('20049','0','0','OTC类，有保护',NULL,'辽宁大连',NULL,'OTC类，有保护',NULL,NULL,'李利',NULL,'12352155','',NULL,NULL,'0',NULL,'2014-11-29 10:36:00','58','0','1','0');");
E_D("replace into `zzcms_dl` values('20050','0','0','有市场保护的',NULL,'重庆涪陵',NULL,'有市场保护的',NULL,NULL,'有市场保护的',NULL,'12342342345','',NULL,NULL,'0',NULL,'2014-11-29 10:36:00','56','0','1','0');");
E_D("replace into `zzcms_dl` values('20051','xiyao','0','有市场保护的','河北','古冶区',NULL,'多年市场售销经验，有固定售销渠道。','','','李志阳','','13838064110','357856668@qq.com',NULL,NULL,'0',NULL,'2016-04-17 08:59:21','88','0','1','0');");
E_D("replace into `zzcms_dl` values('20086','xiyao','632','asdf','北京','',NULL,'sdf','','','李志阳','郑州市南阳路258号','13838064112','357856668@qq.com','Dtest','Dtest','1',NULL,'2016-09-25 10:25:48','22','1','1','0');");
E_D("replace into `zzcms_dl` values('20087','xiyao','632','asdf','全国','市辖区',NULL,'我对这个产品感兴趣，请与我联系。','个人','','李志阳',NULL,'13838064122','357856668@qq.com','Dtest','Dtest','1',NULL,'2016-09-25 10:26:42','11','0','1','0');");

require("../../inc/footer.php");
?>