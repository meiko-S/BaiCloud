<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_usersetting`;");
E_C("CREATE TABLE `zzcms_usersetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `skin` varchar(255) DEFAULT '1',
  `skin_mobile` varchar(50) NOT NULL DEFAULT '1',
  `mobile` varchar(255) DEFAULT NULL,
  `daohang` varchar(255) DEFAULT NULL,
  `bannerbg` varchar(255) DEFAULT NULL,
  `bannerheight` int(11) DEFAULT '160',
  `swf` varchar(255) DEFAULT NULL,
  `comanestyle` varchar(255) DEFAULT NULL,
  `comanecolor` varchar(255) DEFAULT NULL,
  `tongji` varchar(255) DEFAULT NULL,
  `baidu_map` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=845 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_usersetting` values('1','gzqiyunchun','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('2','sytkj72','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('3','cn3555553cn','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('4','cn355553cn','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('5','2323434','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('6','chinaeee','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('7','cmehexpo','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('8','qnawff37','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('9','ljtfeng','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('10','ljtzk','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('11','abccabc','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('12','lizhiheng123','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('13','huar2012','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('14','chdg','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('15','qzf123','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('17','dyjl','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('18','daningtang','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('19','wtla','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('20','1234','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('21','bir023','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('22','gengen','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('23','xugen','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('24','cjzy','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('25','lftz','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('26','tiandayiliao','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('27','www808114com','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('28','cihangmeng','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('29','cbc8145','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('30','hashuai','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('31','master','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('32','djh110520','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('33','zylanyu','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('34','lanyu','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('35','0722cn','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('36','djh11','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('37','15171364226','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('38','200598636','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('39','xiaoxiao','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('40','paipai','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('41','xinhongsw','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('42','yinghuo','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('43','sdhksw','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('44','qnawff02','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('45','fdfh36','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('46','280684602','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('47','timvdu','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('48','zmts123','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('49','jinghuan','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('50','wsf168','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('51','qnawff01','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('52','1212','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('53','feng09g','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('54','bear3qq','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('55','zhjl1012','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('56','zhj1012','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('57','sxznts123','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('58','sun8721','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('59','129600','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('60','xiaoqijulebu','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('61','lym74','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('62','lym740629','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('63','lyma','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('64','qsyy009','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('66','antibody','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('67','leorio','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('68','awennihao','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('69','gpsqjn','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('70','zhonghuang','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('71','123456a','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('72','yuyi','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('73','google','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('74','nihaoma','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('75','chdg0329','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('76','11111111','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('77','juju8','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('78','0000','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('79','yy88888','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('80','ourhsk','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('81','222222','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('82','zzzcms','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('83','cninfochina','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('84','sunkangjie','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('86','aaaaaaa','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('87','sayok','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('88','becreal','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('89','tulao7','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('90','minghonghk','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('91','kmlzb','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('92','myzzz','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('93','280622482','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('94','actifit','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('95','xizhirang','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('96','jiankangleyuan','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('97','xazhyy','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('98','sxdayehaiyy','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('99','huangyutang20','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('100','xianggang','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('101','test','huagong4','1','0','网站首页,招商信息,品牌信息,公司简介,公司新闻,招聘信息,资质证书,联系方式,在线留言','','200','qipao3.swf','center','#000000','<script language=javascript type=text/javascript src=http://js.users.51.la/16955397.js></script>','http://j.map.baidu.com/otmU3');");
E_D("replace into `zzcms_usersetting` values('102','ghswyy','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('103','wangluo','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('105','ceshi000','red2','1','0','网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言','','110','19.swf','no','#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('106','daningtang2013','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('107','1711582866','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('108','cn35553cn','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('109','daningtang2012','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('110','zdk8133','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('111','albahir','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('112','ttt111','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('114','sanchu0517','fangzhi3','1','18171672568','网站首页,招商信息,品牌信息,公司简介,公司新闻,招聘信息,资质证书,联系方式,在线留言','','110','yangguang.swf','center','#000000','','');");
E_D("replace into `zzcms_usersetting` values('115','zdkj','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('144','wwww','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('145','haoguang','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('146','A1111','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('147','bky1314','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('148','jd123','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('152','baku','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('153','minghonghk0','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('154','20131112222408657','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('158','hongping','red2','1','','网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言','','110','12.swf','left','#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('159','hndjlm','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('161','baitongbaili','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('177','natlee','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('178','huanqiuhu001','green2_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言',NULL,'110','6.swf',NULL,'#000000',NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('182','hntf','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('183','zjmyy','blue1','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('184','wm8466','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('185','asasa','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('187','qiyewl','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('188','uguanjia','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('191','zhuan888','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('192','nongzi','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('194','hkjy','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('195','jianceyi66','red2_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('198','hndj','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('200','fu5502','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('201','sanchu6733','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('202','osovosov','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('205','zbhyw','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('207','conbuy','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('208','xmmhyy','blue2_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('209','nosuo','green3_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('211','zhang800buy','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('215','hzy5201314','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('223','wj7908','green2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('227','fengpeony668','blue1_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('228','huhulili','red2_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('229','ybbjp','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('231','admin989','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('233','1165120','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('238','305060258','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('240','hbwdt','blue1','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('242','hgsanchu01','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('255','hacklg','red2','1',NULL,'网站首页, 招商信息, 公司简介, 资质证书, 联系方式, 在线留言',NULL,'110','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('265','hkbhtmy123','green3_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('266','sdhksk','green','1','0','网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言','','160','6.swf','left','#FFFFFF','',NULL);");
E_D("replace into `zzcms_usersetting` values('268','123qwe','hzp4','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('750','maoge','red2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('756','','','1',NULL,'网站首页, 招商信息, 公司简介, 资质证书, 联系方式, 在线留言',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('757','yile020','green3_2','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('758','janelletqy','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('759','brandicewa','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('760','qlmdb2015','green','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('762','jeanineukb','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('763','yy434486','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('764','shtlsw','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('765','beishi','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('766','sadfsadf','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('767','shandongky','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('768','65657577','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('769','dbyweb','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('773','zzl888','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('774','zzl888','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('775','aawwdd','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('776','jz876321','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('777','aikesi','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('778','erin168','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('779','wkr126','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('781','mz3294003185','jiaju55','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('782','3294003185','fuzhuang','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('784','andyzhao','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('785','lmd520','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('786','myht753369','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('789','aikesi117','tongyong','1','15094938886','网站首页,招商信息,品牌信息,公司简介,招聘信息,资质证书,联系方式,在线留言','','160','6.swf','left','#FFFFFF','','');");
E_D("replace into `zzcms_usersetting` values('815','lzy0371','taiyangneng','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('816','yunman','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('817','taoshi123','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('823','lihao3580','tongyong','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('828','test''','red2','1',NULL,'网站首页, 招商信息, 公司简介, 资质证书, 联系方式, 在线留言',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('829','test'' AND (SELECT * FROM  (SELECT(SLEEP(1)))N) AND ''1''=''1','red2','1',NULL,'网站首页, 招商信息, 公司简介, 资质证书, 联系方式, 在线留言',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('830','test'' AND (SELECT * FROM  (SELECT(SLEEP(1)))N) AND ''1=''1','red2','1',NULL,'网站首页, 招商信息, 公司简介, 资质证书, 联系方式, 在线留言',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('841','Dtest','huagong3','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('842','yls666','taiyangneng','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");
E_D("replace into `zzcms_usersetting` values('843','xsser','tongyong6','1',NULL,'网站首页,招商信息,品牌信息,公司简介,资质证书,联系方式,在线留言,招聘信息',NULL,'160','6.swf',NULL,NULL,NULL,NULL);");

require("../../inc/footer.php");
?>