<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_looked_dls_number_oneday`;");
E_C("CREATE TABLE `zzcms_looked_dls_number_oneday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `looked_dls_number_oneday` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_looked_dls_number_oneday` values('1','1','test','2016-08-10 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('2','6','cccccc','2013-09-06 18:04:42');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('3','1','eeeeee','2013-09-14 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('4','1','hongping','2013-12-05 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('5','1','123123','2013-12-20 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('6','1','123qwe','2015-07-20 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('7','12','sanchu0517','2015-08-07 16:14:55');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('8','3','feqr','2015-10-20 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('9','1','test11','2015-12-14 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('10','2','test88999','2016-02-18 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('11','4','ceshi01','2016-03-09 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('12','2','taoshi123','2016-04-24 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('13','1','test2','2016-04-25 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('14','1','test3','2016-06-28 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('15','4','test9922','2016-07-16 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('16','1','Dtest','2016-09-25 00:00:00');");
E_D("replace into `zzcms_looked_dls_number_oneday` values('17','8','xsser','2016-10-08 16:40:47');");

require("../../inc/footer.php");
?>