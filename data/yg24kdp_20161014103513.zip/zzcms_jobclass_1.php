<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_jobclass`;");
E_C("CREATE TABLE `zzcms_jobclass` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(255) DEFAULT NULL,
  `parentid` int(11) DEFAULT '0',
  `xuhao` int(11) DEFAULT '0',
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_jobclass` values('1','生物/制药','0','0');");
E_D("replace into `zzcms_jobclass` values('2','医疗/卫生','0','0');");
E_D("replace into `zzcms_jobclass` values('3','美容/保健','0','0');");
E_D("replace into `zzcms_jobclass` values('4','医疗器械','0','0');");
E_D("replace into `zzcms_jobclass` values('5','药店/医药连锁','0','0');");
E_D("replace into `zzcms_jobclass` values('6','医学媒体','0','0');");
E_D("replace into `zzcms_jobclass` values('7','高级管理','1','0');");
E_D("replace into `zzcms_jobclass` values('8','市场总监','1','0');");
E_D("replace into `zzcms_jobclass` values('9','市场经理/专员','1','0');");
E_D("replace into `zzcms_jobclass` values('10','产品经理','1','0');");
E_D("replace into `zzcms_jobclass` values('11','市场调研/助理','1','0');");
E_D("replace into `zzcms_jobclass` values('12','营销总监','1','0');");
E_D("replace into `zzcms_jobclass` values('13','大区经理','1','0');");
E_D("replace into `zzcms_jobclass` values('14','销售经理/代表','1','0');");
E_D("replace into `zzcms_jobclass` values('15','学科带头人','2','0');");
E_D("replace into `zzcms_jobclass` values('16','医院管理/医务部/护理部','2','0');");
E_D("replace into `zzcms_jobclass` values('17','护士/护理人员','2','0');");
E_D("replace into `zzcms_jobclass` values('18','全科医生','2','0');");
E_D("replace into `zzcms_jobclass` values('19','妇幼保健','2','0');");
E_D("replace into `zzcms_jobclass` values('20','健康咨询','2','0');");
E_D("replace into `zzcms_jobclass` values('21','整脊师','3','0');");
E_D("replace into `zzcms_jobclass` values('22','健康管理师','3','0');");
E_D("replace into `zzcms_jobclass` values('23','针灸推拿/理疗师','3','0');");
E_D("replace into `zzcms_jobclass` values('24','美容保健营销/管理','3','0');");
E_D("replace into `zzcms_jobclass` values('25','公共营养师','3','0');");
E_D("replace into `zzcms_jobclass` values('26','足疗师','3','0');");
E_D("replace into `zzcms_jobclass` values('27','高级管理','4','0');");
E_D("replace into `zzcms_jobclass` values('28','生产管理','4','0');");
E_D("replace into `zzcms_jobclass` values('29','产品设计工程师','4','0');");
E_D("replace into `zzcms_jobclass` values('30','生产制造人员','4','0');");
E_D("replace into `zzcms_jobclass` values('31','医药器械销售经理/主管','4','0');");
E_D("replace into `zzcms_jobclass` values('32','医疗器械销售','4','0');");
E_D("replace into `zzcms_jobclass` values('33','医疗机械注册专员','4','0');");
E_D("replace into `zzcms_jobclass` values('34','高级管理','5','0');");
E_D("replace into `zzcms_jobclass` values('35','店长','5','0');");
E_D("replace into `zzcms_jobclass` values('36','执业药师/驻店药师(西医)','5','0');");
E_D("replace into `zzcms_jobclass` values('37','执业药师/驻店药师(中医)','5','0');");
E_D("replace into `zzcms_jobclass` values('38','理货员','5','0');");
E_D("replace into `zzcms_jobclass` values('39','营业员/店员/导购员','5','0');");
E_D("replace into `zzcms_jobclass` values('40','收银员','5','0');");
E_D("replace into `zzcms_jobclass` values('41','连锁拓展','5','0');");
E_D("replace into `zzcms_jobclass` values('42','校对','6','0');");
E_D("replace into `zzcms_jobclass` values('43','编辑','6','0');");
E_D("replace into `zzcms_jobclass` values('44','发行主任/专员','6','0');");
E_D("replace into `zzcms_jobclass` values('45','公务活动','6','0');");
E_D("replace into `zzcms_jobclass` values('46','编辑记者','6','0');");
E_D("replace into `zzcms_jobclass` values('47','美编','6','0');");
E_D("replace into `zzcms_jobclass` values('48','策划文案','6','0');");
E_D("replace into `zzcms_jobclass` values('49','网络运营','6','0');");

require("../../inc/footer.php");
?>