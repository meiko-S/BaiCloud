<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_usergroup`;");
E_C("CREATE TABLE `zzcms_usergroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL DEFAULT '1',
  `groupname` varchar(255) NOT NULL,
  `grouppic` varchar(255) NOT NULL,
  `RMB` int(11) NOT NULL DEFAULT '0',
  `config` varchar(1000) NOT NULL DEFAULT '0',
  `looked_dls_number_oneday` int(11) NOT NULL DEFAULT '0',
  `refresh_number` int(11) NOT NULL DEFAULT '0',
  `addinfo_number` int(11) NOT NULL DEFAULT '0',
  `addinfototle_number` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_usergroup` values('2','2','vip会员','/image/level2.gif','2800','look_dls_data#look_dls_liuyan#dls_print#dls_download#set_mobile#set_elite#uploadflv#set_zt#seo#showcontact#showad_inzt#zsshow_template','100','10','100','1000');");
E_D("replace into `zzcms_usergroup` values('3','1','普通会员','/image/level1.gif','0','look_dls_data#look_dls_liuyan#showcontact#dls_print#dls_download#set_mobile#set_zt#set_elite#uploadflv#seoshowad_inzt','10','3','10','100');");
E_D("replace into `zzcms_usergroup` values('4','3','高级会员','/image/level3.gif','6000','look_dls_data#look_dls_liuyan#dls_print#dls_download#set_mobile#set_text_adv#set_elite#uploadflv#set_zt#passed#seo#showcontact#showad_inzt#zsshow_template','999','999','999','999');");

require("../../inc/footer.php");
?>