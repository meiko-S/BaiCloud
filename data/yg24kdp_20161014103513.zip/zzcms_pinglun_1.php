<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_pinglun`;");
E_C("CREATE TABLE `zzcms_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `about` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `face` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `passed` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_pinglun` values('6','189','哈哈 这个说的真不错','','未登陆用户','106.37.236.238','2014-10-04 02:07:08','1');");
E_D("replace into `zzcms_pinglun` values('10','201','asdf','','未登陆用户','171.13.51.124','2015-07-17 21:31:17','1');");
E_D("replace into `zzcms_pinglun` values('11','189','asdfasfd','','未登陆用户','106.42.130.248','2015-08-06 11:03:47','1');");
E_D("replace into `zzcms_pinglun` values('12','201','红红火火吧','','未登陆用户','115.60.199.222','2015-10-19 16:01:10','1');");
E_D("replace into `zzcms_pinglun` values('14','201','操','','未登陆用户','125.108.81.98','2016-05-14 22:57:53','0');");
E_D("replace into `zzcms_pinglun` values('15','8','1''','','未登录用户','221.221.181.194','2016-10-08 16:50:49','0');");

require("../../inc/footer.php");
?>