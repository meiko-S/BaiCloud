<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_message`;");
E_C("CREATE TABLE `zzcms_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `sendto` varchar(50) NOT NULL,
  `looked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_message` values('1','收到了吗？','收到了吗？ 收到了吗？oopio-iu','2013-09-28 16:50:29','test','0');");
E_D("replace into `zzcms_message` values('3','asdf','asdf','2013-12-06 00:29:05','','0');");

require("../../inc/footer.php");
?>