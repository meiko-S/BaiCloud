<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_dl_baojianpin`;");
E_C("CREATE TABLE `zzcms_dl_baojianpin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dlid` int(11) DEFAULT '0',
  `cpid` int(11) DEFAULT '0',
  `cp` varchar(255) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `xiancheng` varchar(50) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `dlsname` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `editor` varchar(255) DEFAULT NULL,
  `saver` varchar(255) DEFAULT NULL,
  `savergroupid` int(11) DEFAULT '0',
  `ip` varchar(255) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `hit` int(11) DEFAULT '0',
  `looked` tinyint(4) DEFAULT '0',
  `passed` tinyint(4) DEFAULT '0',
  `del` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `province` (`province`,`city`,`xiancheng`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_dl_baojianpin` values('1','20020','40','哪里能买武唐秘酒','','河南濮阳',NULL,'我对这个产品感兴趣，请与我联系。','个人','','李志阳',NULL,'13838064112','357856668@qq.com','','test','3',NULL,'2016-01-16 21:02:30','0','0','1','0');");

require("../../inc/footer.php");
?>