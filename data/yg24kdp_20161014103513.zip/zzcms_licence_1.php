<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_licence`;");
E_C("CREATE TABLE `zzcms_licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `passed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_licence` values('1','','','cn35553cn','2016-10-09 10:09:34','1');");
E_D("replace into `zzcms_licence` values('2','组织机构代码证','/uploadfiles/2013-06/20130620065614167.jpg','cn35553cn','2013-06-20 14:56:24','1');");
E_D("replace into `zzcms_licence` values('3','营业执照','/uploadfiles/2013-07/20130711005212550.jpg','sanchu0517','2013-07-11 08:52:17','1');");
E_D("replace into `zzcms_licence` values('4','组织机构代码','/uploadfiles/2013-07/20130711005227758.jpg','sanchu0517','2013-07-11 08:52:35','1');");
E_D("replace into `zzcms_licence` values('5','税务登记证','/uploadfiles/2013-07/20130711005245237.jpg','sanchu0517','2013-07-11 08:52:52','1');");
E_D("replace into `zzcms_licence` values('6','zzc','/uploadfiles/2013-09/20130908073318102.jpg','test','2013-09-08 15:33:23','1');");
E_D("replace into `zzcms_licence` values('16','营业执照','/uploadfiles/2013-12/20131209013952903.jpg','hongping','2013-12-09 09:40:00','1');");
E_D("replace into `zzcms_licence` values('31','营业执照','/uploadfiles/2014-03/20140319033710463.jpg','xmmhyy','2014-03-19 11:37:20','1');");
E_D("replace into `zzcms_licence` values('32','营业执照','/uploadfiles/2014-03/20140324034423369.jpg','xmmhyy','2014-03-24 11:44:31','1');");
E_D("replace into `zzcms_licence` values('37','营业执照','/./uploadfiles/2014-04/20140426040442708.jpg','wj7908','2014-04-26 12:05:11','1');");
E_D("replace into `zzcms_licence` values('38','生产许可证','/./uploadfiles/2014-04/20140426040535697.jpg','wj7908','2014-04-26 12:05:56','1');");
E_D("replace into `zzcms_licence` values('39','税务登记证','/./uploadfiles/2014-04/20140426040618788.jpg','wj7908','2014-04-26 12:06:43','1');");
E_D("replace into `zzcms_licence` values('49','营业执照','/uploadfiles/2015-11/20151103134355296.jpg','shandongky','2015-11-03 21:44:09','1');");
E_D("replace into `zzcms_licence` values('50','asdf','/uploadfiles/2016-08/20160802123133297.png','test','2016-08-02 12:31:36','1');");
E_D("replace into `zzcms_licence` values('51','asdf','/uploadfiles/2016-08/20160802123133297.png','test','2016-08-02 12:32:33','1');");

require("../../inc/footer.php");
?>