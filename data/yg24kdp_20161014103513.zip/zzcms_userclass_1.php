<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_userclass`;");
E_C("CREATE TABLE `zzcms_userclass` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(50) NOT NULL DEFAULT '0',
  `parentid` int(11) NOT NULL DEFAULT '0',
  `xuhao` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_userclass` values('1','生产企业','0','0');");
E_D("replace into `zzcms_userclass` values('2','销售企业','0','0');");
E_D("replace into `zzcms_userclass` values('3','类别名称','0','0');");
E_D("replace into `zzcms_userclass` values('4','111111111','0','0');");
E_D("replace into `zzcms_userclass` values('5','医药生产企业','1','0');");

require("../../inc/footer.php");
?>