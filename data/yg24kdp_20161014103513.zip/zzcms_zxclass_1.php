<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_zxclass`;");
E_C("CREATE TABLE `zzcms_zxclass` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(50) DEFAULT NULL,
  `parentid` int(11) DEFAULT '0',
  `xuhao` int(11) DEFAULT '0',
  `isshowforuser` tinyint(4) DEFAULT '1',
  `isshowininfo` tinyint(4) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `discription` varchar(255) DEFAULT NULL,
  `skin` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_zxclass` values('2','展馆介绍','0','7','1','0','展馆介绍','展馆介绍','展馆介绍','zx_class.htm|zx_list.htm');");
E_D("replace into `zzcms_zxclass` values('3','行业趋势','55','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('4','市场分析','55','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('5','营销管理','55','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('6','政策分析','55','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('7','产品质量公告','54','4','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('8','假劣产品警示','54','2','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('9','违法广告通报','54','3','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('10','不良反应及事件','54','5','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('12','两性健康','58','1','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('13','两性生活','58','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('14','两性心理','58','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('15','性爱技巧','58','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('16','两性话题','58','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('17','孕育常识','58','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('18','青春期性教育','58','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('19','性疾病','58','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('20','国家药典','56','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('21','中草药','56','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('22','饮食营养','57','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('23','医疗保健','57','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('24','保健常识','57','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('25','女性保健','57','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('26','老年保健','57','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('27','大众用药','56','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('28','药品常识','56','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('29','营销案例','55','0','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('30','欺诈公示','54','1','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('36','天天保健','0','6','1','1','天天保健','天天保健','天天保健',NULL);");
E_D("replace into `zzcms_zxclass` values('46','其他警示','54','6','1','1','','','',NULL);");
E_D("replace into `zzcms_zxclass` values('53','业内资讯','0','1','1','1','业内资讯','业内资讯','业内资讯',NULL);");
E_D("replace into `zzcms_zxclass` values('54','警示平台','0','2','1','1','警示平台','警示平台','警示平台',NULL);");
E_D("replace into `zzcms_zxclass` values('55','营销文库','0','3','1','1','营销文库','营销文库','营销文库',NULL);");
E_D("replace into `zzcms_zxclass` values('56','医药知识','0','4','1','1','医药知识','医药知识','医药知识',NULL);");
E_D("replace into `zzcms_zxclass` values('58','两性知识','0','5','1','1','两性知识','两性知识','两性知识',NULL);");
E_D("replace into `zzcms_zxclass` values('59','保健常识','36','0','1','1','保健常识','保健常识','保健常识',NULL);");
E_D("replace into `zzcms_zxclass` values('60','饮食营养','36','0','1','1','饮食营养','饮食营养','饮食营养',NULL);");
E_D("replace into `zzcms_zxclass` values('61','医疗保健','36','0','1','1','医疗保健','医疗保健','医疗保健',NULL);");
E_D("replace into `zzcms_zxclass` values('62','女性保健','36','0','1','1','女性保健','女性保健','女性保健',NULL);");
E_D("replace into `zzcms_zxclass` values('63','老年保健','36','0','1','1','老年保健','老年保健','老年保健',NULL);");
E_D("replace into `zzcms_zxclass` values('64','公司新闻','0','0','1','0','公司新闻','公司新闻','公司新闻','zx_class.htm');");

require("../../inc/footer.php");
?>