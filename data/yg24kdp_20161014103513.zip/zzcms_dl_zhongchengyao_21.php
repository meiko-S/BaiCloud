<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("replace into `zzcms_dl_zhongchengyao` values('10001','10001','0','中成药代理测试10000','广西','南宁','马山县','代理测试代理测试代理测试',NULL,NULL,'李志阳',NULL,'13838064112',NULL,'test',NULL,'0',NULL,'2015-11-16 20:01:50','0','0','1','0');");
E_D("replace into `zzcms_dl_zhongchengyao` values('10002','20004','29','谷の宝骨细胞修复液','','河南濮阳',NULL,'','个人','','李志阳',NULL,'13838064112','','','test','2',NULL,'2015-11-21 02:16:26','0','0','1','0');");
E_D("replace into `zzcms_dl_zhongchengyao` values('10003','20005','29','谷の宝骨细胞修复液','','河南濮阳',NULL,'','个人','','李志阳',NULL,'13838064112','','','test','2',NULL,'2015-11-21 02:24:36','0','0','1','0');");
E_D("replace into `zzcms_dl_zhongchengyao` values('10004','20007','358','麝香壮骨膏','','太原市',NULL,'我对这个产品感兴趣，请与我联系。','个人','','张贵娥',NULL,'13544323422','436526234@qq.com','','huanqiuhu001','1',NULL,'2015-11-22 17:39:43','0','0','1','0');");
E_D("replace into `zzcms_dl_zhongchengyao` values('10005','20008','268','rrrrrrrrrrrrrrrrrrrr','北京','江苏南通',NULL,'我对这个产品感兴趣，请与我联系。','个人','','张军',NULL,'13333333333','asdf@qq.com','','test','3',NULL,'2015-11-24 17:11:20','0','0','1','0');");
E_D("replace into `zzcms_dl_zhongchengyao` values('10006','20009','341','嘎日迪五味丸(阜新)','全国','浙江杭州',NULL,'我对这个产品感兴趣，请与我联系。代理价零售价是多少？','个人','','范德萨',NULL,'15556545212','','','hongping','1',NULL,'2015-11-30 12:37:35','0','0','1','0');");
E_D("replace into `zzcms_dl_zhongchengyao` values('10007','20024','228','???','','Quatre Bornes',NULL,'&lt;a href=http://viagraonlinegeneric.nu/&gt;viagra online generic&lt;/a&gt;','??','TiMoxy39nh4','TiMoxy39nh4',NULL,'123456','oronaman@mailer2.cf','','daningtang2013','1',NULL,'2016-01-18 16:31:57','0','0','0','0');");
E_D("replace into `zzcms_dl_zhongchengyao` values('10013','20085','525','腰腿冷敷贴','','北京北京',NULL,'我对这个产品感兴趣，请与我联系。','个人','','北京',NULL,'15023654870','','','qlmdb2015','1',NULL,'2016-07-13 15:41:20','0','0','0','0');");

require("../../inc/footer.php");
?>