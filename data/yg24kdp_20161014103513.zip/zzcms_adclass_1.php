<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_adclass`;");
E_C("CREATE TABLE `zzcms_adclass` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(255) NOT NULL,
  `xuhao` int(11) NOT NULL DEFAULT '0',
  `parentid` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_adclass` values('1','视频下部','0','首页');");
E_D("replace into `zzcms_adclass` values('2','视频右侧','0',NULL);");
E_D("replace into `zzcms_adclass` values('3','视频左侧','0','首页');");
E_D("replace into `zzcms_adclass` values('4','yiliaoqixiezhaoshang','0',NULL);");
E_D("replace into `zzcms_adclass` values('5','baojianpinzhaoshang','0',NULL);");
E_D("replace into `zzcms_adclass` values('6','zhongyaozhaoshang','0',NULL);");
E_D("replace into `zzcms_adclass` values('7','xiyaozhaoshang','0',NULL);");
E_D("replace into `zzcms_adclass` values('8','对联广告右侧','0','首页');");
E_D("replace into `zzcms_adclass` values('9','对联广告左侧','0','首页');");
E_D("replace into `zzcms_adclass` values('10','漂浮广告','0','首页');");
E_D("replace into `zzcms_adclass` values('11','顶部','0','首页');");
E_D("replace into `zzcms_adclass` values('12','品牌招商','0',NULL);");
E_D("replace into `zzcms_adclass` values('13','banner','0',NULL);");
E_D("replace into `zzcms_adclass` values('14','轮显广告','0','展会页');");
E_D("replace into `zzcms_adclass` values('17','未用到的','0',NULL);");
E_D("replace into `zzcms_adclass` values('24','第二行','0','首页');");
E_D("replace into `zzcms_adclass` values('25','资讯频道右侧','0',NULL);");
E_D("replace into `zzcms_adclass` values('26','1F','0','首页');");
E_D("replace into `zzcms_adclass` values('27','展会频道右侧','0',NULL);");
E_D("replace into `zzcms_adclass` values('28','代理频道右侧','0',NULL);");
E_D("replace into `zzcms_adclass` values('29','轮显广告','0','首页');");
E_D("replace into `zzcms_adclass` values('30','招商频道右侧','0',NULL);");
E_D("replace into `zzcms_adclass` values('32','首页第三行','0',NULL);");
E_D("replace into `zzcms_adclass` values('33','第一行','0','首页');");
E_D("replace into `zzcms_adclass` values('35','A','0','首页');");
E_D("replace into `zzcms_adclass` values('36','C','0',NULL);");
E_D("replace into `zzcms_adclass` values('37','A_img','0','首页');");
E_D("replace into `zzcms_adclass` values('38','B','0','首页');");
E_D("replace into `zzcms_adclass` values('39','B_img','0','首页');");
E_D("replace into `zzcms_adclass` values('40','首页','0','A');");
E_D("replace into `zzcms_adclass` values('41','展会页','0','A');");
E_D("replace into `zzcms_adclass` values('42','品牌招商','0','首页');");
E_D("replace into `zzcms_adclass` values('43','视频右侧','0','首页');");
E_D("replace into `zzcms_adclass` values('47','西药','0','A');");
E_D("replace into `zzcms_adclass` values('48','保健品','0','A');");
E_D("replace into `zzcms_adclass` values('49','上部','0','西药');");
E_D("replace into `zzcms_adclass` values('50','上部','0','保健品');");
E_D("replace into `zzcms_adclass` values('51','中部','0','西药');");
E_D("replace into `zzcms_adclass` values('52','中部','0','保健品');");
E_D("replace into `zzcms_adclass` values('53','中成药','0','A');");
E_D("replace into `zzcms_adclass` values('54','上部','0','中成药');");
E_D("replace into `zzcms_adclass` values('55','下部','0','中成药');");
E_D("replace into `zzcms_adclass` values('56','医疗器械','0','A');");
E_D("replace into `zzcms_adclass` values('57','上部','0','医疗器械');");
E_D("replace into `zzcms_adclass` values('58','下部','0','医疗器械');");
E_D("replace into `zzcms_adclass` values('59','A_img','0','西药');");
E_D("replace into `zzcms_adclass` values('60','A_img','0','中成药');");
E_D("replace into `zzcms_adclass` values('61','A_img','0','保健品');");
E_D("replace into `zzcms_adclass` values('62','A_img','0','医疗器械');");
E_D("replace into `zzcms_adclass` values('64','底部','0','保健品');");
E_D("replace into `zzcms_adclass` values('65','分类招商间','0','西药');");
E_D("replace into `zzcms_adclass` values('66','分类招商间','0','保健品');");

require("../../inc/footer.php");
?>