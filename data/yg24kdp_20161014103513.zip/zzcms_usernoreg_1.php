<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_usernoreg`;");
E_C("CREATE TABLE `zzcms_usernoreg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usersf` varchar(50) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `comane` varchar(255) DEFAULT NULL,
  `kind` int(11) NOT NULL DEFAULT '0',
  `somane` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `checkcode` varchar(255) DEFAULT NULL,
  `regdate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_usernoreg` values('44','公司','test123123','test','','0','王姐无','15369741032','76919405@qq.com','20140914001153467','2014-09-14 00:11:53');");
E_D("replace into `zzcms_usernoreg` values('47','公司','look','ka123465','阿拉山口的几幅','0','阿拉山口的几幅','15212345869','4545@456.com','20140923131503209','2014-09-23 13:15:03');");
E_D("replace into `zzcms_usernoreg` values('48','公司','kill','123123','天意达医药','0','杜先生','18745484545','1231@qq.com','20140925132621154','2014-09-25 13:26:21');");
E_D("replace into `zzcms_usernoreg` values('49','公司','test201','test201','威海康贝尔生物公司','0','李志阳','1123412341234','357856668@qq.com','20140926140734328','2014-09-26 14:07:34');");
E_D("replace into `zzcms_usernoreg` values('50','公司','ttchbr','chbrchbr888','百乐访','0','百乐访','13325478954','fkdjkjkgk@126.com','20141004011808964','2014-10-04 01:18:08');");
E_D("replace into `zzcms_usernoreg` values('51','公司','chbr888','521016tsj','博彩网','0','博彩网','13325478954','314169904@qq.com','20141004011914135','2014-10-04 01:19:14');");

require("../../inc/footer.php");
?>