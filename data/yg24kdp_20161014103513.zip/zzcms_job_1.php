<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_job`;");
E_C("CREATE TABLE `zzcms_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bigclassid` int(11) DEFAULT '0',
  `bigclassname` varchar(255) DEFAULT NULL,
  `smallclassid` int(11) DEFAULT '0',
  `smallclassname` varchar(255) DEFAULT NULL,
  `jobname` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `sm` varchar(1000) DEFAULT NULL,
  `editor` varchar(255) DEFAULT NULL,
  `comane` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT '0',
  `sendtime` datetime DEFAULT NULL,
  `hit` int(11) DEFAULT '0',
  `passed` tinyint(4) NOT NULL DEFAULT '0',
  `xiancheng` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_job` values('5','1','生物/制药','7','高级管理','asdf','湖南','长沙','asf','test','河南大禹药业有限公司','101','2014-11-27 01:10:02','576','1',NULL);");
E_D("replace into `zzcms_job` values('6','2','医疗/卫生','15','学科带头人','rt5y6u','湖南','株洲','rt5y6u','test','河南大禹药业有限公司','101','2014-11-27 01:10:16','772','1',NULL);");
E_D("replace into `zzcms_job` values('7','2','医疗/卫生','16','医院管理/医务部/护理部','fffgbyjik','山东','淄博','fffgbyjik','test','河南大禹药业有限公司','101','2014-11-27 01:10:34','646','1',NULL);");
E_D("replace into `zzcms_job` values('8','3','美容/保健','22','健康管理师','asfdfffffffffr','河南','开封','rrrrrrrrrrrr','test','河南大禹药业有限公司','101','2014-11-27 01:10:46','625','1',NULL);");
E_D("replace into `zzcms_job` values('9','3','美容/保健','21','整脊师','njkdfsadsd','湖北','宜昌','njkdfsadsd','test','河南大禹药业有限公司','101','2014-11-27 01:11:02','649','1',NULL);");
E_D("replace into `zzcms_job` values('10','5','药店/医药连锁','35','店长','店长店长店长店长店长店长店长店长店长店长店长店长店长店长店长店长店长店长','湖北','请选择城区','店长店长店长店长店长店长店长店长店长店长店长店长店长','test','河南大禹药业有限公司','101','2016-08-09 17:25:52','679','1','');");
E_D("replace into `zzcms_job` values('41','5','药店/医药连锁','35','店长','店长','山东','滨州市','店长店长店长店长店长店长','test','河南大禹药业有限公司','101','2016-08-09 17:25:33','29','1','滨城区');");
E_D("replace into `zzcms_job` values('42','5','药店/医药连锁','35','店长','店长店长店长店长店长店长','湖北','随州市','店长店长','test','河南大禹药业有限公司','101','2016-08-09 17:26:14','22','1','曾都区');");
E_D("replace into `zzcms_job` values('43','2','医疗/卫生','17','护士/护理人员','护士/护理人员','湖北','随州市','护士/护理人员','test','河南大禹药业有限公司','101','2016-08-09 17:26:35','28','1','曾都区');");
E_D("replace into `zzcms_job` values('44','2','医疗/卫生','18','全科医生','全科医生','湖北','随州市','全科医生','test','河南大禹药业有限公司','101','2016-08-09 17:31:56','34','1','曾都区');");

require("../../inc/footer.php");
?>