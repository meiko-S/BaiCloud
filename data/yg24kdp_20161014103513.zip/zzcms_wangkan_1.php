<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_wangkan`;");
E_C("CREATE TABLE `zzcms_wangkan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bigclassid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` longtext,
  `img` varchar(255) DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `hit` int(11) DEFAULT '0',
  `passed` tinyint(4) DEFAULT '0',
  `elite` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_wangkan` values('1','1','第一期','<img alt=\"\" src=\"/uploadfiles/2016-09/20160929201242859.jpg\" style=\"width: 720px; height: 1280px;\" /><img alt=\"\" src=\"/uploadfiles/2016-09/20160929201026188.jpg\" style=\"width: 640px; height: 960px;\" /><img alt=\"\" src=\"/uploadfiles/2016-09/20160929201036521.jpg\" style=\"width: 640px; height: 960px;\" /><img alt=\"\" src=\"/uploadfiles/2016-09/20160929201048388.jpg\" style=\"width: 640px; height: 960px;\" />','/uploadfiles/2016-09/20160929201242859.jpg',NULL,'2016-09-29 20:12:45','24','1','0');");

require("../../inc/footer.php");
?>