<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("replace into `zzcms_dl_xiyao` values('10038','20084','201','小儿贝诺酯维B1颗粒','全国','天津天津',NULL,'我对这个产品感兴趣，请与我联系。','个人','','吕先生',NULL,'18537111214','lvzhukui@hnhqxy.com','','test','3',NULL,'2016-07-04 20:25:55','0','0','0','0');");
E_D("replace into `zzcms_dl_xiyao` values('10039','20086','632','asdf','北京','',NULL,'sdf','','','李志阳','郑州市南阳路258号','13838064112','357856668@qq.com','Dtest','Dtest','1',NULL,'2016-09-25 10:25:48','0','0','1','0');");
E_D("replace into `zzcms_dl_xiyao` values('10040','20087','632','asdf','全国','市辖区',NULL,'我对这个产品感兴趣，请与我联系。','个人','','李志阳',NULL,'13838064122','357856668@qq.com','Dtest','Dtest','1',NULL,'2016-09-25 10:26:42','0','0','1','0');");
E_D("replace into `zzcms_dl_xiyao` values('10041','20088','0','&lt;iframe src=&quot;data:text/html,&lt;script&gt;alert(1)','河南','郑州市',NULL,'&lt;iframe src=&quot;data:text/html,&lt;script&gt;alert(1)&lt;/script&gt;&quot;&gt;&lt;/iframe&gt; Chrome''&quot;&gt;&lt;img/src=x onerror=alert(2001)&gt;&lt;&quot;''\r\n&lt;p&gt;&lt;img src=&quot;1&quot; onerror=&quot;alert(1212)&quot;/&gt;&lt;/p&gt;','个人','','&lt;iframe src=&quot;data:text/html,&lt;script&gt;alert(1)&lt;/script&gt;&quot;&gt;&lt;/iframe&gt; Chrome''&quot;&gt;&lt;img/src=x onerror=alert(2001)&gt;&lt;&quot;'' &lt;p&gt;&lt;img src=&quot;1&quot; onerror=&quot;alert(1212)&quot;/&gt;&lt;/p&gt;','','11','123012@qq.com','xsser',NULL,'0',NULL,'2016-10-08 16:20:56','0','0','0','0');");

require("../../inc/footer.php");
?>