<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_specialclass`;");
E_C("CREATE TABLE `zzcms_specialclass` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(50) DEFAULT NULL,
  `parentid` int(11) DEFAULT '0',
  `xuhao` int(11) DEFAULT '0',
  `isshowforuser` tinyint(4) DEFAULT '1',
  `isshowininfo` tinyint(4) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `discription` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_specialclass` values('1','广州药交会','0','0','1','1','广州药交会','广州药交会','广州药交会');");
E_D("replace into `zzcms_specialclass` values('2','访谈','1','0','1','1','','','');");
E_D("replace into `zzcms_specialclass` values('3','名企直击','1','0','1','1','','','');");
E_D("replace into `zzcms_specialclass` values('4','展会现场','1','0','1','1','','','');");
E_D("replace into `zzcms_specialclass` values('5','展会简介','1','0','1','1','','','');");
E_D("replace into `zzcms_specialclass` values('6','大背景图','1','0','0','0','大背景图','大背景图','大背景图');");
E_D("replace into `zzcms_specialclass` values('7','2015成都春季全国糖酒会','0','0','1','1','2015成都春季全国糖酒会','2015成都春季全国糖酒会','2015成都春季全国糖酒会');");
E_D("replace into `zzcms_specialclass` values('8','访谈','7','0','1','1',NULL,NULL,NULL);");
E_D("replace into `zzcms_specialclass` values('9','大背景图','7','0','0','0','大背景图','大背景图','大背景图');");
E_D("replace into `zzcms_specialclass` values('10','展会现场','7','0','1','1',NULL,NULL,NULL);");
E_D("replace into `zzcms_specialclass` values('11','展会简介','7','0','1','1',NULL,NULL,NULL);");
E_D("replace into `zzcms_specialclass` values('12','名企直击','7','0','1','1',NULL,NULL,NULL);");

require("../../inc/footer.php");
?>