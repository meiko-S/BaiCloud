<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_wangkanclass`;");
E_C("CREATE TABLE `zzcms_wangkanclass` (
  `bigclassid` int(11) NOT NULL AUTO_INCREMENT,
  `bigclassname` varchar(50) DEFAULT NULL,
  `xuhao` int(11) DEFAULT '0',
  PRIMARY KEY (`bigclassid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_wangkanclass` values('1','网刊类别1','0');");

require("../../inc/footer.php");
?>