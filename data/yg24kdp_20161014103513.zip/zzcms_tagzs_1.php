<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_tagzs`;");
E_C("CREATE TABLE `zzcms_tagzs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `xuhao` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_tagzs` values('30','关键词','#','0');");
E_D("replace into `zzcms_tagzs` values('31','关键词2','#','0');");
E_D("replace into `zzcms_tagzs` values('32','关键词4','#','0');");
E_D("replace into `zzcms_tagzs` values('33','关键词3','#','0');");
E_D("replace into `zzcms_tagzs` values('34','关键词5','#','0');");
E_D("replace into `zzcms_tagzs` values('35','关键词66','http://#','0');");

require("../../inc/footer.php");
?>