<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_zsclass`;");
E_C("CREATE TABLE `zzcms_zsclass` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` varchar(255) NOT NULL DEFAULT 'A',
  `classname` varchar(255) NOT NULL,
  `classzm` varchar(255) NOT NULL,
  `img` varchar(50) NOT NULL DEFAULT '0',
  `xuhao` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `discription` varchar(255) NOT NULL,
  `isshow` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_zsclass` values('1','xiyao','神经内科','shenjingneike','0','18','神经内科','神经内科','神经内科','1');");
E_D("replace into `zzcms_zsclass` values('2','xiyao','循环系统','xunhuanxitong','0','3','循环系统','循环系统','循环系统','1');");
E_D("replace into `zzcms_zsclass` values('3','xiyao','呼吸科','huxike','0','4','呼吸科','呼吸科','呼吸科','1');");
E_D("replace into `zzcms_zsclass` values('4','xiyao','消化科','xiaohuake','0','6','消化科','消化科','消化科','1');");
E_D("replace into `zzcms_zsclass` values('5','xiyao','泌尿科','miniaoke','0','7','泌尿科1','泌尿科1','泌尿科1','1');");
E_D("replace into `zzcms_zsclass` values('6','xiyao','耳鼻喉科','erbihouke','0','9','耳鼻喉科','耳鼻喉科','耳鼻喉科','1');");
E_D("replace into `zzcms_zsclass` values('7','xiyao','抗菌/抗病毒','kangjun','0','5','抗菌/抗病毒','抗菌/抗病毒','抗菌/抗病毒','1');");
E_D("replace into `zzcms_zsclass` values('8','xiyao','抗寄生虫','kangjishengchong','0','30','抗寄生虫','抗寄生虫','抗寄生虫','1');");
E_D("replace into `zzcms_zsclass` values('9','xiyao','肿瘤科','zhongliuke','0','14','肿瘤科','肿瘤科','肿瘤科','1');");
E_D("replace into `zzcms_zsclass` values('10','xiyao','皮肤科','pifuke','0','23','皮肤科','皮肤科','皮肤科','1');");
E_D("replace into `zzcms_zsclass` values('11','xiyao','维生素','weishengsu','0','11','维生素','维生素','维生素','1');");
E_D("replace into `zzcms_zsclass` values('12','zhongchengyao','外科用药','waike','0','11','外科用药','外科用药','外科用药','1');");
E_D("replace into `zzcms_zsclass` values('13','zhongchengyao','妇科用药','fuke','0','20','妇科用药','妇科用药','妇科用药','1');");
E_D("replace into `zzcms_zsclass` values('14','zhongchengyao','儿科用药','erke','0','21','儿科用药','儿科用药','儿科用药','1');");
E_D("replace into `zzcms_zsclass` values('15','zhongchengyao','耳鼻咽喉','erbiyanhou','0','2','耳鼻咽喉','耳鼻咽喉','耳鼻咽喉','1');");
E_D("replace into `zzcms_zsclass` values('16','zhongchengyao','骨伤科','gushangke','0','31','骨伤科','骨伤科','骨伤科','1');");
E_D("replace into `zzcms_zsclass` values('17','zhongchengyao','皮肤科','pifuke','0','5','皮肤科','皮肤科','皮肤科','1');");
E_D("replace into `zzcms_zsclass` values('18','baojianpin','微量元素','wiliangyuansu','0','0','微量元素','微量元素','微量元素','1');");
E_D("replace into `zzcms_zsclass` values('19','baojianpin','调节血脂','tiaojixuezhi','0','0','调节血脂','调节血脂','调节血脂','1');");
E_D("replace into `zzcms_zsclass` values('20','baojianpin','美容养颜','meirongyangyan','0','0','美容养颜','美容养颜','美容养颜','1');");
E_D("replace into `zzcms_zsclass` values('21','yiliaoqixie','治疗仪','zhiliaoyi','0','0','治疗仪','治疗仪','治疗仪','1');");
E_D("replace into `zzcms_zsclass` values('22','baojianpin','调节免疫','tiaojimianyi','0','0','调节免疫','调节免疫','调节免疫','1');");
E_D("replace into `zzcms_zsclass` values('23','baojianpin','减肥瘦身','jianfeishoushen','0','0','减肥瘦身','减肥瘦身','减肥瘦身','1');");
E_D("replace into `zzcms_zsclass` values('24','baojianpin','改善视力','gaishanshili','0','0','改善视力','改善视力','改善视力','1');");
E_D("replace into `zzcms_zsclass` values('25','baojianpin','计生品','jishengpin','0','1','计生品','计生品','计生品','1');");
E_D("replace into `zzcms_zsclass` values('26','baojianpin','改善性功能','gaishanxinggongneng','0','2','改善性功能','改善性功能','改善性功能','1');");
E_D("replace into `zzcms_zsclass` values('27','xiyao','内科用药','neike','0','6','内科用药','内科用药','内科用药','1');");
E_D("replace into `zzcms_zsclass` values('28','yiliaoqixie','贴剂/膏药','tieji','0','0','贴剂/膏药','贴剂/膏药','贴剂/膏药','1');");
E_D("replace into `zzcms_zsclass` values('29','zhongchengyao','其它','qita','0','100','其它','其它','其它','1');");
E_D("replace into `zzcms_zsclass` values('30','baojianpin','改善记忆','gaishanjiyi','0','0','改善记忆','改善记忆','改善记忆','1');");
E_D("replace into `zzcms_zsclass` values('31','baojianpin','延缓抗衰','yanhuankangshuai','0','0','延缓抗衰','延缓抗衰','延缓抗衰','1');");
E_D("replace into `zzcms_zsclass` values('32','yiliaoqixie','避孕器械','biyunqixie','0','0','避孕器械','避孕器械','避孕器械','1');");
E_D("replace into `zzcms_zsclass` values('33','yiliaoqixie','能量治疗','ningliangzhiliao','0','0','能量治疗','能量治疗','能量治疗','1');");
E_D("replace into `zzcms_zsclass` values('34','yiliaoqixie','护理设备','hulishebei','0','0','护理设备','护理设备','护理设备','1');");
E_D("replace into `zzcms_zsclass` values('35','yiliaoqixie','清洁消毒','qingjiexiaodu','0','0','清洁消毒','清洁消毒','清洁消毒','1');");
E_D("replace into `zzcms_zsclass` values('36','yiliaoqixie','外科器械','waikeqixie','0','0','外科器械','外科器械','外科器械','1');");
E_D("replace into `zzcms_zsclass` values('37','yiliaoqixie','药液输送','yaoyishushong','0','0','药液输送','药液输送','药液输送','1');");
E_D("replace into `zzcms_zsclass` values('38','yiliaoqixie','药液保存','yaoyibaochun','0','0','药液保存','药液保存','药液保存','1');");
E_D("replace into `zzcms_zsclass` values('39','yiliaoqixie','诊断监护','zhenduanjianhu','0','0','诊断监护','诊断监护','诊断监护','1');");
E_D("replace into `zzcms_zsclass` values('40','yiliaoqixie','医用敷料','yiyongfuliao','0','0','医用敷料','医用敷料','医用敷料','1');");
E_D("replace into `zzcms_zsclass` values('41','yiliaoqixie','其它器械','qitaqixie','0','1','其它器械','其它器械','其它器械','1');");
E_D("replace into `zzcms_zsclass` values('42','xiyao','免疫系统','mianyixitong','0','31','免疫系统','免疫系统','免疫系统','1');");
E_D("replace into `zzcms_zsclass` values('43','xiyao','微量元素','weiliangyuansu','0','13','微量元素','微量元素','微量元素','1');");
E_D("replace into `zzcms_zsclass` values('44','xiyao','妇科用药','fuke','0','16','妇科用药','妇科用药','妇科用药','1');");
E_D("replace into `zzcms_zsclass` values('45','xiyao','解热镇痛','jierezhentong','0','19','解热镇痛','解热镇痛','解热镇痛','1');");
E_D("replace into `zzcms_zsclass` values('46','xiyao','内分泌科','neifenmi','0','1','内分泌科','内分泌科','内分泌科','1');");
E_D("replace into `zzcms_zsclass` values('47','xiyao','糖尿病','tangniaobing','0','2','糖尿病','糖尿病','糖尿病','1');");
E_D("replace into `zzcms_zsclass` values('48','xiyao','氨基酸','anjishuan','0','20','氨基酸','氨基酸','氨基酸','1');");
E_D("replace into `zzcms_zsclass` values('49','xiyao','外科用药','waike','0','10','外科用药1','外科用药1','外科用药1','1');");
E_D("replace into `zzcms_zsclass` values('50','xiyao','消毒防腐','xiaodufangfu','0','21','消毒防腐','消毒防腐','消毒防腐','1');");
E_D("replace into `zzcms_zsclass` values('51','xiyao','血液系统','xueyiexitong','0','15','血液系统','血液系统','血液系统','1');");
E_D("replace into `zzcms_zsclass` values('52','xiyao','儿科用药','erkeyongyao','0','22','儿科用药','儿科用药','儿科用药','1');");
E_D("replace into `zzcms_zsclass` values('53','xiyao','骨科用药','guke','0','27','骨科用药','骨科用药','骨科用药','1');");
E_D("replace into `zzcms_zsclass` values('54','xiyao','心血管科','xinnaoxueguan','0','24','心血管科','心血管科','心血管科','1');");
E_D("replace into `zzcms_zsclass` values('55','xiyao','肝胆用药','gandan','0','25','肝胆用药','肝胆用药','肝胆用药','1');");
E_D("replace into `zzcms_zsclass` values('56','xiyao','肾病科','shenbing','0','12','肾病科','肾病科','肾病科','1');");
E_D("replace into `zzcms_zsclass` values('57','zhongchengyao','扶正药','fuzheng','0','14','扶正药','扶正药','扶正药','1');");
E_D("replace into `zzcms_zsclass` values('58','zhongchengyao','泻下/固涩','xiexia','0','16','泻下/固涩','泻下/固涩','泻下/固涩','1');");
E_D("replace into `zzcms_zsclass` values('59','zhongchengyao','眼科用药','yanke','0','12','眼科用药','眼科用药','眼科用药','1');");
E_D("replace into `zzcms_zsclass` values('60','zhongchengyao','前列腺','qianliexian','0','7','前列腺','前列腺','前列腺','1');");
E_D("replace into `zzcms_zsclass` values('61','zhongchengyao','祛暑/解表','qushu','0','4','祛暑/解表','祛暑/解表','祛暑/解表','1');");
E_D("replace into `zzcms_zsclass` values('62','zhongchengyao','肝胆用药','gandanyongyao','0','17','肝胆用药','肝胆用药','肝胆用药','1');");
E_D("replace into `zzcms_zsclass` values('63','zhongchengyao','风湿关节炎','fengshiguanjieyan','0','32','风湿关节炎','风湿关节炎','风湿关节炎','1');");
E_D("replace into `zzcms_zsclass` values('64','zhongchengyao','糖尿病','tangniaobing','0','1','糖尿病','糖尿病','糖尿病','1');");
E_D("replace into `zzcms_zsclass` values('65','zhongchengyao','中风后遗症','zhongfeng','0','33','中风后遗症','中风后遗症','中风后遗症','1');");
E_D("replace into `zzcms_zsclass` values('66','zhongchengyao','清热解毒','qingrejiedu','0','24','清热解毒','清热解毒','清热解毒','1');");
E_D("replace into `zzcms_zsclass` values('67','zhongchengyao','胃肠用药','weichang','0','23','胃肠用药','胃肠用药','胃肠用药','1');");
E_D("replace into `zzcms_zsclass` values('68','zhongchengyao','民族药','minzhuyao','0','22','民族药','民族药','民族药','1');");
E_D("replace into `zzcms_zsclass` values('69','zhongchengyao','安神/补血','anshenbuxue','0','15','安神/补血','安神/补血','安神/补血','1');");
E_D("replace into `zzcms_zsclass` values('70','zhongchengyao','理血/降脂','lixuejiangzhi','0','8','理血/降脂','理血/降脂','理血/降脂','1');");
E_D("replace into `zzcms_zsclass` values('71','zhongchengyao','泌尿生殖','miniaoshengzhi','0','9','泌尿生殖','泌尿生殖','泌尿生殖','1');");
E_D("replace into `zzcms_zsclass` values('72','zhongchengyao','化痰/止咳','huatanzhike','0','3','化痰/止咳','化痰/止咳','化痰/止咳','1');");
E_D("replace into `zzcms_zsclass` values('73','A','西药','xiyao','0','1','西药招商','西药招商','西药招商','1');");
E_D("replace into `zzcms_zsclass` values('74','A','中成药','zhongchengyao','0','2','中成药','中成药','中成药','1');");
E_D("replace into `zzcms_zsclass` values('75','yiliaoqixie','植入器械','zhiruqixie','0','0','植入器械','植入器械','植入器械','1');");
E_D("replace into `zzcms_zsclass` values('76','xiyao','其它','qita','0','100','其它','其它','其它','1');");
E_D("replace into `zzcms_zsclass` values('77','baojianpin','其它','qita','0','10','其它','其它','其它','1');");
E_D("replace into `zzcms_zsclass` values('79','xiyao','口腔科','kouqiangke','0','32','口腔科','口腔科','口腔科','1');");
E_D("replace into `zzcms_zsclass` values('80','xiyao','颅脑外科','lunaowaike','0','33','颅脑外科','颅脑外科','颅脑外科','1');");
E_D("replace into `zzcms_zsclass` values('81','xiyao','产科用药','chanke','0','34','产科用药','产科用药','产科用药','1');");
E_D("replace into `zzcms_zsclass` values('83','xiyao','肝胆科','gandanke','0','35','肝胆科','肝胆科','肝胆科','1');");
E_D("replace into `zzcms_zsclass` values('84','xiyao','性病科','xingbingke','0','36','性病科','性病科','性病科','1');");
E_D("replace into `zzcms_zsclass` values('85','xiyao','眼科用药','yanke','0','37','眼科用药1','眼科用药1','眼科用药1','1');");
E_D("replace into `zzcms_zsclass` values('86','xiyao','烧伤科','shaoshangke','0','38','烧伤科','烧伤科','烧伤科','1');");
E_D("replace into `zzcms_zsclass` values('88','zhongchengyao','利湿通淋','lishitonglin','0','19','利湿通淋','利湿通淋','利湿通淋','1');");
E_D("replace into `zzcms_zsclass` values('89','zhongchengyao','肿瘤用药','zhongliu','0','18','肿瘤用药','肿瘤用药','肿瘤用药','1');");
E_D("replace into `zzcms_zsclass` values('90','zhongchengyao','口腔科','kouqiangke','0','13','口腔科','口腔科','口腔科','1');");
E_D("replace into `zzcms_zsclass` values('91','A','保健品','baojianpin','0','3','保健品','保健品','保健品','1');");
E_D("replace into `zzcms_zsclass` values('92','A','医疗器械','yiliaoqixie','0','4','医疗器械','医疗器械','医疗器械','1');");
E_D("replace into `zzcms_zsclass` values('98','A','药妆','yaozhuang','0','5','药妆','药妆','药妆','1');");
E_D("replace into `zzcms_zsclass` values('99','A','医药包装','yiyaobaozhuang','0','6','医药包装','医药包装','医药包装','1');");
E_D("replace into `zzcms_zsclass` values('100','yaozhuang','延缓细胞老化','yanhuanxibaolaohua','0','0','新加子类1','新加子类1','新加子类1','1');");
E_D("replace into `zzcms_zsclass` values('101','yaozhuang','促进皮肤微循环','cujinpifuweixunhuan','0','0','促进皮肤微循环','促进皮肤微循环','促进皮肤微循环','1');");
E_D("replace into `zzcms_zsclass` values('102','yaozhuang','修护保养','xiuhubaoyang','0','0','修护保养','修护保养','修护保养','1');");
E_D("replace into `zzcms_zsclass` values('103','yiyaobaozhuang','纸类包装','zhileibaozhuang','0','0','纸类包装','纸类包装','纸类包装','1');");
E_D("replace into `zzcms_zsclass` values('104','yiyaobaozhuang','塑料类包装','suliaoleibaozhuang','0','0','塑料类包装','塑料类包装','塑料类包装','1');");
E_D("replace into `zzcms_zsclass` values('105','yiyaobaozhuang','金属类包装','jinshuleibaozhuang','0','0','金属类包装','金属类包装','金属类包装','1');");
E_D("replace into `zzcms_zsclass` values('108','yiyaobaozhuang','玻璃和陶瓷类包装','bolihetaocileibaozhuang','0','0','玻璃和陶瓷类包装','玻璃和陶瓷类包装','玻璃和陶瓷类包装','1');");
E_D("replace into `zzcms_zsclass` values('109','yiyaobaozhuang','木材和复合材料类包装','mucaihefuhecailiaoleibaozhuang','0','0','木材和复合材料类包装','木材和复合材料类包装','木材和复合材料类包装','1');");
E_D("replace into `zzcms_zsclass` values('110','yiyaobaozhuang','其他包装','qitabaozhuang','0','0','其他包装','其他包装','其他包装','1');");

require("../../inc/footer.php");
?>