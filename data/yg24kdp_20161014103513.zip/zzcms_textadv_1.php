<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_textadv`;");
E_C("CREATE TABLE `zzcms_textadv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adv` varchar(255) DEFAULT NULL,
  `company` varchar(255) NOT NULL,
  `advlink` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `gxsj` datetime DEFAULT NULL,
  `newsid` int(11) NOT NULL DEFAULT '0',
  `passed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `adv` (`adv`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_textadv` values('6','特色蒙药招商-洪萍','山东健志医药科技开发有限公司','/zt/show-158.htm','/uploadfiles/2013-12/20131209013914819.jpg','hongping','2013-12-05 14:52:12','91','1');");
E_D("replace into `zzcms_textadv` values('41','1','','/zt/show-.htm','','','2016-09-29 11:34:58','0','0');");

require("../../inc/footer.php");
?>