<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_link`;");
E_C("CREATE TABLE `zzcms_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bigclassid` int(11) DEFAULT '0',
  `sitename` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `elite` tinyint(4) DEFAULT '0',
  `passed` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=425 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_link` values('422','3','sdfg','sdfg','sdfg','2016-04-17 10:35:02','','0','1');");
E_D("replace into `zzcms_link` values('423','3','asdf','http://sss.com','asdf','2016-05-25 13:58:19','http://ss.com','1','1');");

require("../../inc/footer.php");
?>