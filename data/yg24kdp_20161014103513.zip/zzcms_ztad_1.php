<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_ztad`;");
E_C("CREATE TABLE `zzcms_ztad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  `passed` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=236 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_ztad` values('2','焦点图片广告','asdf','###','/uploadfiles/2016-03/20160326114631117.jpg','test','1');");
E_D("replace into `zzcms_ztad` values('3','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('4','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('5','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('6','%e7%84%a6%e7%82%b9%e5%9b%be%e7%89%87%e5%b9%bf%e5%91%8a','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('7','%e7%84%a6%e7%82%b9%e5%9b%be%e7%89%87%e5%b9%bf%e5%91%8a','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('8','2rN61vzm','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('9','-1 OR 2+540-540-1=0+0+0+1 --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('10','-1 OR 2+13-13-1=0+0+0+1','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('11','-1'' OR 2+755-755-1=0+0+0+1 --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('12','-1'' OR 2+943-943-1=0+0+0+1 or ''lQrJFqJy''=''','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('13','-1&quot; OR 2+312-312-1=0+0+0+1 --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('14','if(now()=sysdate(),sleep(3),0)/*''XOR(if(now()=sysdate(),sleep(3),0))OR''&quot;XOR(if(now()=sysdate(),sleep(3),0))OR&quot;*/','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('15','(select(0)from(select(sleep(3)))v)/*''+(select(0)from(select(sleep(3)))v)+''&quot;+(select(0)from(select(sleep(3)))v)+&quot;*/','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('16','1 waitfor delay ''0:0:6'' --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('17','YzqM9W8d''; waitfor delay ''0:0:6'' --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('18','DM871vc6''); waitfor delay ''0:0:6'' --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('19','7gIgdjjb'')); waitfor delay ''0:0:6'' --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('20','焦点图片广告','Mr.','1','','','1');");
E_D("replace into `zzcms_ztad` values('21','aODmujkj'');select pg_sleep(9); --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('22','g01nq83c''));select pg_sleep(9); --','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('23','焦点图片广告','Mr.','1','','1','0');");
E_D("replace into `zzcms_ztad` values('24','焦点图片广告','Mr.','1','','1','0');");
E_D("replace into `zzcms_ztad` values('25','焦点图片广告','Mr.','1','','QE6s0xnL','0');");
E_D("replace into `zzcms_ztad` values('26','焦点图片广告','Mr.','1','','-1 OR 2+666-666-1=0+0+0+1 --','0');");
E_D("replace into `zzcms_ztad` values('27','焦点图片广告','Mr.','1','','-1 OR 2+953-953-1=0+0+0+1','0');");
E_D("replace into `zzcms_ztad` values('28','焦点图片广告','Mr.','1','','-1'' OR 2+506-506-1=0+0+0+1 --','0');");
E_D("replace into `zzcms_ztad` values('29','焦点图片广告','Mr.','1','','-1'' OR 2+274-274-1=0+0+0+1 or ''Lj1oqgL1''=''','0');");
E_D("replace into `zzcms_ztad` values('30','焦点图片广告','Mr.','1','','-1&quot; OR 2+611-611-1=0+0+0+1 --','0');");
E_D("replace into `zzcms_ztad` values('31','焦点图片广告','Mr.','1','','-1; waitfor delay ''0:0:3'' --','0');");
E_D("replace into `zzcms_ztad` values('32','焦点图片广告','Mr.','1','','-1); waitfor delay ''0:0:3'' --','0');");
E_D("replace into `zzcms_ztad` values('33','焦点图片广告','Mr.','1','','-1)); waitfor delay ''0:0:3'' --','0');");
E_D("replace into `zzcms_ztad` values('34','焦点图片广告','Mr.','1','','1 waitfor delay ''0:0:6'' --','0');");
E_D("replace into `zzcms_ztad` values('35','焦点图片广告','Mr.','1','','jLrWndV6''; waitfor delay ''0:0:6'' --','0');");
E_D("replace into `zzcms_ztad` values('36','焦点图片广告','Mr.','1','','UlYpqd0k''); waitfor delay ''0:0:6'' --','0');");
E_D("replace into `zzcms_ztad` values('37','焦点图片广告','Mr.','1','','Gynt0awu'')); waitfor delay ''0:0:9'' --','0');");
E_D("replace into `zzcms_ztad` values('38','焦点图片广告','Mr.','1','','-1;select pg_sleep(9); --','0');");
E_D("replace into `zzcms_ztad` values('39','焦点图片广告','Mr.','1','','-1);select pg_sleep(9); --','0');");
E_D("replace into `zzcms_ztad` values('40','焦点图片广告','Mr.','1','','-1));select pg_sleep(9); --','0');");
E_D("replace into `zzcms_ztad` values('41','焦点图片广告','Mr.','1','','cDP3VXHj'';select pg_sleep(9); --','0');");
E_D("replace into `zzcms_ztad` values('42','焦点图片广告','Mr.','1','','8X97nqGr'');select pg_sleep(3); --','0');");
E_D("replace into `zzcms_ztad` values('43','焦点图片广告','Mr.','1','','kymQxU23''));select pg_sleep(3); --','0');");
E_D("replace into `zzcms_ztad` values('44','焦点图片广告','Mr.','1','1','','1');");
E_D("replace into `zzcms_ztad` values('45','焦点图片广告','Mr.','1','1','','0');");
E_D("replace into `zzcms_ztad` values('46','焦点图片广告','Mr.','1','C9X5Oo02','','0');");
E_D("replace into `zzcms_ztad` values('47','焦点图片广告','Mr.','1','-1 OR 2+920-920-1=0+0+0+1 --','','0');");
E_D("replace into `zzcms_ztad` values('48','焦点图片广告','Mr.','1','-1 OR 2+221-221-1=0+0+0+1','','0');");
E_D("replace into `zzcms_ztad` values('49','焦点图片广告','Mr.','1','-1'' OR 2+471-471-1=0+0+0+1 --','','0');");
E_D("replace into `zzcms_ztad` values('50','焦点图片广告','Mr.','1','-1'' OR 2+534-534-1=0+0+0+1 or ''GuiRewFS''=''','','0');");
E_D("replace into `zzcms_ztad` values('53','焦点图片广告','Mr.','1','(select(0)from(select(sleep(3)))v)/*''+(select(0)from(select(sleep(3)))v)+''&quot;+(select(0)from(select(sleep(3)))v)+&quot;*/','','0');");
E_D("replace into `zzcms_ztad` values('54','焦点图片广告','Mr.','1','-1; waitfor delay ''0:0:3'' --','','0');");
E_D("replace into `zzcms_ztad` values('55','焦点图片广告','Mr.','1','-1); waitfor delay ''0:0:6'' --','','0');");
E_D("replace into `zzcms_ztad` values('56','焦点图片广告','Mr.','1','-1)); waitfor delay ''0:0:6'' --','','0');");
E_D("replace into `zzcms_ztad` values('57','焦点图片广告','Mr.','1','1 waitfor delay ''0:0:6'' --','','0');");
E_D("replace into `zzcms_ztad` values('58','焦点图片广告','Mr.','1','vlZWxkCT''; waitfor delay ''0:0:6'' --','','0');");
E_D("replace into `zzcms_ztad` values('59','焦点图片广告','Mr.','1','qUE4R7wg''); waitfor delay ''0:0:9'' --','','0');");
E_D("replace into `zzcms_ztad` values('60','焦点图片广告','Mr.','1','UCtQT3TV'')); waitfor delay ''0:0:9'' --','','0');");
E_D("replace into `zzcms_ztad` values('61','焦点图片广告','Mr.','1','-1;select pg_sleep(9); --','','0');");
E_D("replace into `zzcms_ztad` values('63','焦点图片广告','Mr.','1','-1));select pg_sleep(3); --','','0');");
E_D("replace into `zzcms_ztad` values('65','焦点图片广告','Mr.','1','XDgpBh5F'');select pg_sleep(3); --','','0');");
E_D("replace into `zzcms_ztad` values('67','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('68','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('69','焦点图片广告','Mr.','tR6BkolX','','','0');");
E_D("replace into `zzcms_ztad` values('70','焦点图片广告','Mr.','-1 OR 2+574-574-1=0+0+0+1 --','','','0');");
E_D("replace into `zzcms_ztad` values('71','焦点图片广告','Mr.','-1 OR 2+360-360-1=0+0+0+1','','','0');");
E_D("replace into `zzcms_ztad` values('72','焦点图片广告','Mr.','-1'' OR 2+506-506-1=0+0+0+1 --','','','0');");
E_D("replace into `zzcms_ztad` values('73','焦点图片广告','Mr.','-1'' OR 2+323-323-1=0+0+0+1 or ''iHAYOjuT''=''','','','0');");
E_D("replace into `zzcms_ztad` values('74','焦点图片广告','Mr.','-1&quot; OR 2+436-436-1=0+0+0+1 --','','','0');");
E_D("replace into `zzcms_ztad` values('75','焦点图片广告','Mr.','if(now()=sysdate(),sleep(6),0)/*''XOR(if(now()=sysdate(),sleep(6),0))OR''&quot;XOR(if(now()=sysdate(),sleep(6),0))OR&quot;*/','','','0');");
E_D("replace into `zzcms_ztad` values('76','焦点图片广告','Mr.','(select(0)from(select(sleep(6)))v)/*''+(select(0)from(select(sleep(6)))v)+''&quot;+(select(0)from(select(sleep(6)))v)+&quot;*/','','','0');");
E_D("replace into `zzcms_ztad` values('77','焦点图片广告','Mr.','-1; waitfor delay ''0:0:9'' --','','','0');");
E_D("replace into `zzcms_ztad` values('78','焦点图片广告','Mr.','-1); waitfor delay ''0:0:9'' --','','','0');");
E_D("replace into `zzcms_ztad` values('79','焦点图片广告','Mr.','-1)); waitfor delay ''0:0:9'' --','','','0');");
E_D("replace into `zzcms_ztad` values('80','焦点图片广告','Mr.','1 waitfor delay ''0:0:9'' --','','','0');");
E_D("replace into `zzcms_ztad` values('81','焦点图片广告','Mr.','2mSw4iJD''; waitfor delay ''0:0:9'' --','','','0');");
E_D("replace into `zzcms_ztad` values('82','焦点图片广告','Mr.','oefaGSoK''); waitfor delay ''0:0:3'' --','','','0');");
E_D("replace into `zzcms_ztad` values('83','焦点图片广告','Mr.','qALj8fZX'')); waitfor delay ''0:0:3'' --','','','0');");
E_D("replace into `zzcms_ztad` values('84','焦点图片广告','Mr.','-1;select pg_sleep(3); --','','','0');");
E_D("replace into `zzcms_ztad` values('85','焦点图片广告','Mr.','-1);select pg_sleep(3); --','','','0');");
E_D("replace into `zzcms_ztad` values('86','焦点图片广告','Mr.','-1));select pg_sleep(6); --','','','0');");
E_D("replace into `zzcms_ztad` values('87','焦点图片广告','Mr.','V42M4EnX'';select pg_sleep(6); --','','','0');");
E_D("replace into `zzcms_ztad` values('88','焦点图片广告','Mr.','gjKSqrPf'');select pg_sleep(6); --','','','0');");
E_D("replace into `zzcms_ztad` values('89','焦点图片广告','Mr.','1','','','1');");
E_D("replace into `zzcms_ztad` values('90','焦点图片广告','Mr.','1','','','1');");
E_D("replace into `zzcms_ztad` values('91','焦点图片广告','Mr.','1','','','1');");
E_D("replace into `zzcms_ztad` values('92','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('93','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('94','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('95','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('96','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('97','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('98','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('99','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('100','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('101','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('102','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('103','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('104','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('105','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('106','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('107','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('108','焦点图片广告','Mr.','1','','','0');");
E_D("replace into `zzcms_ztad` values('109','焦点图片广告','r8ADv5eC','1','','','0');");
E_D("replace into `zzcms_ztad` values('110','焦点图片广告','-1 OR 2+316-316-1=0+0+0+1 --','1','','','0');");
E_D("replace into `zzcms_ztad` values('111','焦点图片广告','-1 OR 3+316-316-1=0+0+0+1 --','1','','','0');");
E_D("replace into `zzcms_ztad` values('112','焦点图片广告','-1 OR 3+316-316-1=0+0+0+1 --','1','','','0');");
E_D("replace into `zzcms_ztad` values('113','焦点图片广告','-1 OR 3*2&lt;(0+5+316-316) --','1','','','0');");
E_D("replace into `zzcms_ztad` values('144','焦点图片广告','Mr.','1','','1''&quot;','0');");
E_D("replace into `zzcms_ztad` values('145','焦点图片广告','Mr.','1','','\\\\','0');");
E_D("replace into `zzcms_ztad` values('146','焦点图片广告','Mr.','1','','@@BrKXb','0');");
E_D("replace into `zzcms_ztad` values('147','焦点图片广告','Mr.','1','','JyI=','0');");
E_D("replace into `zzcms_ztad` values('148','焦点图片广告','Mr.','1','','(select convert(int,CHAR(65)))','0');");
E_D("replace into `zzcms_ztad` values('172','焦点图片广告','ASDF','###','/uploadfiles/2016-03/20160326114448867.jpg','test','1');");
E_D("replace into `zzcms_ztad` values('175','焦点图片广告','1','1','','xsser','1');");
E_D("replace into `zzcms_ztad` values('176','焦点图片广告','1','1','','xsser','1');");
E_D("replace into `zzcms_ztad` values('177','焦点图片广告','1''','1''','','xsser','1');");
E_D("replace into `zzcms_ztad` values('178','焦点图片广告','1''','1''','','xsser','1');");
E_D("replace into `zzcms_ztad` values('179','焦点图片广告','1''','1''','','xsser','1');");
E_D("replace into `zzcms_ztad` values('181','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('182','焦点图片广告','88952634''`&quot;(','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('183','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('184','焦点图片广告','88952634-0','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('185','焦点图片广告','88952634s3','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('186','焦点图片广告','88952634''+''','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('187','焦点图片广告','88952634''','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('188','焦点图片广告','88952634''||''','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('189','焦点图片广告','88952634''','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('190','焦点图片广告','88952634&lt;alert(88952634)&gt;','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('191','焦点图片广告','88952634','88952634''`&quot;(','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('192','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('193','焦点图片广告','88952634','88952634-0','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('194','焦点图片广告','88952634','88952634s3','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('195','焦点图片广告','88952634','88952634''+''','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('196','焦点图片广告','88952634','88952634''','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('197','焦点图片广告','88952634','88952634''||''','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('198','焦点图片广告','88952634','88952634''','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('199','焦点图片广告','88952634','88952634&lt;alert(88952634)&gt;','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('200','焦点图片广告','88952634','88952634','88952634''`&quot;(','88952634','1');");
E_D("replace into `zzcms_ztad` values('201','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('202','焦点图片广告','88952634','88952634','88952634-0','88952634','1');");
E_D("replace into `zzcms_ztad` values('203','焦点图片广告','88952634','88952634','88952634s3','88952634','1');");
E_D("replace into `zzcms_ztad` values('204','焦点图片广告','88952634','88952634','88952634''+''','88952634','1');");
E_D("replace into `zzcms_ztad` values('205','焦点图片广告','88952634','88952634','88952634''','88952634','1');");
E_D("replace into `zzcms_ztad` values('206','焦点图片广告','88952634','88952634','88952634''||''','88952634','1');");
E_D("replace into `zzcms_ztad` values('207','焦点图片广告','88952634','88952634','88952634''','88952634','1');");
E_D("replace into `zzcms_ztad` values('208','焦点图片广告','88952634','88952634','88952634&lt;alert(88952634)&gt;','88952634','1');");
E_D("replace into `zzcms_ztad` values('209','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('210','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('211','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('212','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('213','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('214','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('215','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('216','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('217','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('218','焦点图片广告','88952634','88952634','88952634','88952634''`&quot;(','1');");
E_D("replace into `zzcms_ztad` values('219','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('220','焦点图片广告','88952634','88952634','88952634','88952634-0','1');");
E_D("replace into `zzcms_ztad` values('221','焦点图片广告','88952634','88952634','88952634','88952634s3','1');");
E_D("replace into `zzcms_ztad` values('222','焦点图片广告','88952634','88952634','88952634','88952634''+''','1');");
E_D("replace into `zzcms_ztad` values('223','焦点图片广告','88952634','88952634','88952634','88952634''','1');");
E_D("replace into `zzcms_ztad` values('224','焦点图片广告','88952634','88952634','88952634','88952634''||''','1');");
E_D("replace into `zzcms_ztad` values('225','焦点图片广告','88952634','88952634','88952634','88952634''','1');");
E_D("replace into `zzcms_ztad` values('226','焦点图片广告','88952634','88952634','88952634','88952634&lt;alert(88952634)&gt;','1');");
E_D("replace into `zzcms_ztad` values('227','焦点图片广告''`&quot;(','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('228','焦点图片广告','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('229','焦点图片广告-0','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('230','焦点图片广告s3','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('231','焦点图片广告''+''','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('232','焦点图片广告''','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('233','焦点图片广告''||''','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('234','焦点图片广告''','88952634','88952634','88952634','88952634','1');");
E_D("replace into `zzcms_ztad` values('235','焦点图片广告&lt;alert(88952634)&gt;','88952634','88952634','88952634','88952634','1');");

require("../../inc/footer.php");
?>