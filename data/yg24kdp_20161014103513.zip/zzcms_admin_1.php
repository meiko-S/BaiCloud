<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `zzcms_admin`;");
E_C("CREATE TABLE `zzcms_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) DEFAULT NULL,
  `admin` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `logins` int(11) DEFAULT '0',
  `loginip` varchar(255) DEFAULT NULL,
  `lastlogintime` datetime DEFAULT NULL,
  `showloginip` varchar(255) DEFAULT NULL,
  `showlogintime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8");
E_D("replace into `zzcms_admin` values('9','3','lzy','23e154176ce521794d960ffd823f1720','590','106.46.154.3','2016-10-14 10:07:00','171.12.158.202','2016-10-10 14:23:06');");
E_D("replace into `zzcms_admin` values('12','2','admin','98bfe7780b3044eba8560c4a35455a18','30','120.0.213.195','2016-10-08 15:59:17','221.221.181.194','2016-10-08 15:00:44');");

require("../../inc/footer.php");
?>